package com.example.smsscheduler;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PERMS = 1;
    private static final int PRIMARY = 0xFF00796B;
    private static final int PRIMARY_DARK = 0xFF004D40;

    private static final String[] WEEK_NAMES = {
            "السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"};
    private static final int[] WEEK_VALUES = {
            Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY,
            Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY};

    private final List<Schedule> items = new ArrayList<>();
    private ScheduleAdapter adapter;
    private TextView emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().setStatusBarColor(PRIMARY_DARK);
        buildUi();
        requestNeededPermissions();
        checkExactAlarm();
        Scheduler.rescheduleAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    // ------------------------------------------------------------------ الواجهة

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF2F4F5);

        TextView header = new TextView(this);
        header.setText("جدولة الرسائل");
        header.setTextColor(Color.WHITE);
        header.setTextSize(22);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setBackgroundColor(PRIMARY);
        header.setPadding(dp(20), dp(16), dp(20), dp(16));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("اضغط على الرسالة للتعديل • اضغط مطولاً للإرسال الآن أو الحذف");
        hint.setTextColor(0xFF607D8B);
        hint.setTextSize(12);
        hint.setPadding(dp(20), dp(10), dp(20), dp(0));
        root.addView(hint);

        FrameLayout listFrame = new FrameLayout(this);
        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(dp(10), dp(6), dp(10), dp(6));
        list.setClipToPadding(false);
        adapter = new ScheduleAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> showEditor(items.get(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            showActions(items.get(pos));
            return true;
        });
        listFrame.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = new TextView(this);
        emptyView.setText("لا توجد رسائل مجدولة بعد\nاضغط «إضافة رسالة» بالأسفل");
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setTextColor(0xFF90A4AE);
        emptyView.setTextSize(16);
        listFrame.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(listFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button add = new Button(this);
        add.setText("+ إضافة رسالة");
        add.setTextColor(Color.WHITE);
        add.setTextSize(16);
        add.setAllCaps(false);
        add.setBackground(rounded(PRIMARY, 12));
        add.setOnClickListener(v -> showEditor(null));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        lp.setMargins(dp(16), dp(8), dp(16), dp(16));
        root.addView(add, lp);

        setContentView(root);
    }

    private void refresh() {
        items.clear();
        items.addAll(ScheduleStore.getAll(this));
        adapter.notifyDataSetChanged();
        emptyView.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private class ScheduleAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return items.get(i).id; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final Schedule s = items.get(position);

            FrameLayout wrap = new FrameLayout(MainActivity.this);
            wrap.setPadding(0, dp(6), 0, dp(6));

            LinearLayout card = new LinearLayout(MainActivity.this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setBackground(rounded(Color.WHITE, 14));
            card.setPadding(dp(16), dp(14), dp(12), dp(14));
            card.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout texts = new LinearLayout(MainActivity.this);
            texts.setOrientation(LinearLayout.VERTICAL);

            TextView title = new TextView(MainActivity.this);
            title.setText(s.target());
            title.setTextSize(17);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(0xFF263238);
            texts.addView(title);

            TextView msg = new TextView(MainActivity.this);
            msg.setText(s.message);
            msg.setMaxLines(2);
            msg.setEllipsize(TextUtils.TruncateAt.END);
            msg.setTextColor(0xFF546E7A);
            msg.setTextSize(14);
            texts.addView(msg);

            TextView when = new TextView(MainActivity.this);
            when.setText(describe(s));
            when.setTextColor(PRIMARY);
            when.setTextSize(14);
            when.setPadding(0, dp(4), 0, 0);
            texts.addView(when);

            TextView next = new TextView(MainActivity.this);
            next.setTextSize(12);
            next.setTextColor(0xFF78909C);
            if (s.enabled) {
                long t = Scheduler.nextTrigger(s, System.currentTimeMillis());
                next.setText("القادم: " + new SimpleDateFormat("EEEE d MMMM yyyy - hh:mm a",
                        new Locale("ar")).format(new Date(t)));
            } else {
                next.setText("متوقفة");
            }
            texts.addView(next);

            if (!s.lastStatus.isEmpty()) {
                TextView st = new TextView(MainActivity.this);
                st.setText(s.lastStatus);
                st.setTextSize(12);
                st.setTextColor(s.lastStatus.startsWith("✔") ? 0xFF2E7D32 : 0xFFC62828);
                texts.addView(st);
            }

            card.addView(texts, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Switch sw = new Switch(MainActivity.this);
            sw.setChecked(s.enabled);
            sw.setOnCheckedChangeListener((b, checked) -> {
                s.enabled = checked;
                ScheduleStore.save(MainActivity.this, s);
                Scheduler.schedule(MainActivity.this, s);
                refresh();
            });
            card.addView(sw);

            wrap.addView(card, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return wrap;
        }
    }

    // ------------------------------------------------------------------ تعديل / إضافة

    private void showEditor(final Schedule existing) {
        final boolean isNew = existing == null;
        final Schedule s = isNew ? new Schedule() : existing;

        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));
        sv.addView(box);

        final EditText name = field("الاسم (اختياري)", InputType.TYPE_CLASS_TEXT);
        name.setText(s.name);
        box.addView(name);

        final EditText phone = field("رقم الهاتف", InputType.TYPE_CLASS_PHONE);
        phone.setText(s.phone);
        box.addView(phone);

        final EditText msg = field("نص الرسالة",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        msg.setMinLines(3);
        msg.setGravity(Gravity.TOP | Gravity.START);
        msg.setText(s.message);
        box.addView(msg);

        box.addView(label("التكرار"));
        final Spinner typeSp = new Spinner(this);
        typeSp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"أسبوعي", "شهري"}));
        typeSp.setSelection(s.type);
        box.addView(typeSp);

        final TextView dayLabel = label(s.type == Schedule.WEEKLY ? "اليوم من الأسبوع" : "اليوم من الشهر");
        box.addView(dayLabel);
        final Spinner daySp = new Spinner(this);
        fillDays(daySp, s.type, s.type == Schedule.WEEKLY
                ? indexOfWeekday(s.dayOfWeek) : s.dayOfMonth - 1);
        box.addView(daySp);

        final int[] lastType = {s.type};
        typeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (pos == lastType[0]) return;
                lastType[0] = pos;
                dayLabel.setText(pos == Schedule.WEEKLY ? "اليوم من الأسبوع" : "اليوم من الشهر");
                fillDays(daySp, pos, 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        box.addView(label("الوقت"));
        final int[] time = {s.hour, s.minute};
        final Button timeBtn = new Button(this);
        timeBtn.setAllCaps(false);
        timeBtn.setText(formatTime(time[0], time[1]));
        timeBtn.setOnClickListener(v -> new TimePickerDialog(MainActivity.this,
                (view, h, m) -> {
                    time[0] = h;
                    time[1] = m;
                    timeBtn.setText(formatTime(h, m));
                }, time[0], time[1], false).show());
        box.addView(timeBtn);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isNew ? "رسالة جديدة" : "تعديل الرسالة")
                .setView(sv)
                .setPositiveButton("حفظ", null)
                .setNegativeButton("إلغاء", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String number = phone.getText().toString().replaceAll("[\\s-]", "");
            String text = msg.getText().toString().trim();
            if (!number.matches("\\+?[0-9]{3,15}")) {
                phone.setError("أدخل رقم هاتف صحيح");
                return;
            }
            if (text.isEmpty()) {
                msg.setError("اكتب نص الرسالة");
                return;
            }
            s.name = name.getText().toString().trim();
            s.phone = number;
            s.message = text;
            s.type = typeSp.getSelectedItemPosition();
            if (s.type == Schedule.WEEKLY) {
                s.dayOfWeek = WEEK_VALUES[daySp.getSelectedItemPosition()];
            } else {
                s.dayOfMonth = daySp.getSelectedItemPosition() + 1;
            }
            s.hour = time[0];
            s.minute = time[1];

            ScheduleStore.save(MainActivity.this, s);
            Scheduler.schedule(MainActivity.this, s);
            refresh();
            dialog.dismiss();
            Toast.makeText(MainActivity.this, "تم الحفظ", Toast.LENGTH_SHORT).show();
        });
    }

    private void fillDays(Spinner sp, int type, int selected) {
        List<String> names = new ArrayList<>();
        if (type == Schedule.WEEKLY) {
            for (String n : WEEK_NAMES) names.add(n);
        } else {
            for (int d = 1; d <= 31; d++) names.add(String.valueOf(d));
        }
        sp.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, names));
        if (selected >= 0 && selected < names.size()) sp.setSelection(selected);
    }

    private int indexOfWeekday(int calendarDay) {
        for (int i = 0; i < WEEK_VALUES.length; i++) {
            if (WEEK_VALUES[i] == calendarDay) return i;
        }
        return 0;
    }

    // ------------------------------------------------------------------ إجراءات

    private void showActions(final Schedule s) {
        new AlertDialog.Builder(this)
                .setTitle(s.target())
                .setItems(new String[]{"إرسال الآن (تجربة)", "حذف"}, (d, which) -> {
                    if (which == 0) {
                        SmsSender.send(MainActivity.this, s);
                        Toast.makeText(this, "جاري الإرسال…", Toast.LENGTH_SHORT).show();
                    } else {
                        confirmDelete(s);
                    }
                })
                .show();
    }

    private void confirmDelete(final Schedule s) {
        new AlertDialog.Builder(this)
                .setMessage("حذف هذه الرسالة المجدولة؟")
                .setPositiveButton("حذف", (d, w) -> {
                    Scheduler.cancel(this, s.id);
                    ScheduleStore.delete(this, s.id);
                    refresh();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    // ------------------------------------------------------------------ الصلاحيات

    private void requestNeededPermissions() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.SEND_SMS);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        for (int i = 0; i < permissions.length; i++) {
            if (Manifest.permission.SEND_SMS.equals(permissions[i])
                    && results[i] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this,
                        "بدون صلاحية الرسائل لن يستطيع التطبيق الإرسال. فعّلها من إعدادات التطبيق.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void checkExactAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = getSystemService(AlarmManager.class);
            if (!am.canScheduleExactAlarms()) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {
                }
            }
        }
    }

    // ------------------------------------------------------------------ أدوات مساعدة

    private String describe(Schedule s) {
        String t = formatTime(s.hour, s.minute);
        if (s.type == Schedule.WEEKLY) {
            return "كل " + WEEK_NAMES[indexOfWeekday(s.dayOfWeek)] + " الساعة " + t;
        }
        return "يوم " + s.dayOfMonth + " من كل شهر الساعة " + t;
    }

    private String formatTime(int h, int m) {
        int h12 = h % 12 == 0 ? 12 : h % 12;
        return String.format(Locale.US, "%d:%02d %s", h12, m, h < 12 ? "ص" : "م");
    }

    private EditText field(String hint, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(inputType);
        return e;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFF607D8B);
        t.setTextSize(13);
        t.setPadding(0, dp(14), 0, 0);
        return t;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
