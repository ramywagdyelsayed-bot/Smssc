package com.example.smsscheduler;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/** حساب موعد الإرسال القادم وضبط المنبّه عبر AlarmManager. */
public class Scheduler {

    /** أول موعد بعد الوقت from (بالميلي ثانية). */
    public static long nextTrigger(Schedule s, long from) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(from);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.set(Calendar.HOUR_OF_DAY, s.hour);
        c.set(Calendar.MINUTE, s.minute);

        if (s.type == Schedule.WEEKLY) {
            int diff = s.dayOfWeek - c.get(Calendar.DAY_OF_WEEK);
            if (diff < 0) diff += 7;
            c.add(Calendar.DAY_OF_MONTH, diff);
            if (c.getTimeInMillis() <= from) c.add(Calendar.DAY_OF_MONTH, 7);
            return c.getTimeInMillis();
        }

        // شهري: إذا كان الشهر أقصر من اليوم المطلوب (مثل 31) يُستخدم آخر يوم في الشهر
        for (int i = 0; i < 14; i++) {
            Calendar x = (Calendar) c.clone();
            x.set(Calendar.DAY_OF_MONTH, 1);
            x.add(Calendar.MONTH, i);
            int max = x.getActualMaximum(Calendar.DAY_OF_MONTH);
            x.set(Calendar.DAY_OF_MONTH, Math.min(s.dayOfMonth, max));
            if (x.getTimeInMillis() > from) return x.getTimeInMillis();
        }
        return from + 24L * 60 * 60 * 1000;
    }

    private static PendingIntent pending(Context c, int id) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context context, Schedule s) {
        schedule(context, s, System.currentTimeMillis());
    }

    public static void schedule(Context context, Schedule s, long from) {
        Context c = context.getApplicationContext();
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = pending(c, s.id);
        if (!s.enabled) {
            am.cancel(pi);
            return;
        }
        long t = nextTrigger(s, from);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (exact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
        }
    }

    public static void cancel(Context context, int id) {
        Context c = context.getApplicationContext();
        c.getSystemService(AlarmManager.class).cancel(pending(c, id));
    }

    public static void rescheduleAll(Context context) {
        for (Schedule s : ScheduleStore.getAll(context)) {
            schedule(context, s);
        }
    }
}
