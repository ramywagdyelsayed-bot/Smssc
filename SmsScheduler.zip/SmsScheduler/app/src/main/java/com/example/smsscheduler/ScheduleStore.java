package com.example.smsscheduler;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** تخزين الجداول محلياً على الجهاز (SharedPreferences) بدون أي اتصال بالإنترنت. */
public class ScheduleStore {
    private static final String PREFS = "schedules";
    private static final String KEY_DATA = "data";
    private static final String KEY_NEXT_ID = "next_id";

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized List<Schedule> getAll(Context c) {
        List<Schedule> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY_DATA, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                list.add(Schedule.fromJson(arr.getJSONObject(i)));
            }
        } catch (JSONException ignored) {
        }
        return list;
    }

    public static synchronized Schedule get(Context c, int id) {
        for (Schedule s : getAll(c)) {
            if (s.id == id) return s;
        }
        return null;
    }

    private static void writeAll(Context c, List<Schedule> list) {
        JSONArray arr = new JSONArray();
        for (Schedule s : list) {
            try {
                arr.put(s.toJson());
            } catch (JSONException ignored) {
            }
        }
        prefs(c).edit().putString(KEY_DATA, arr.toString()).commit();
    }

    public static synchronized void save(Context c, Schedule s) {
        List<Schedule> list = getAll(c);
        if (s.id == 0) {
            SharedPreferences p = prefs(c);
            int next = p.getInt(KEY_NEXT_ID, 1);
            s.id = next;
            p.edit().putInt(KEY_NEXT_ID, next + 1).commit();
            list.add(s);
        } else {
            boolean found = false;
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).id == s.id) {
                    list.set(i, s);
                    found = true;
                    break;
                }
            }
            if (!found) list.add(s);
        }
        writeAll(c, list);
    }

    public static synchronized void delete(Context c, int id) {
        List<Schedule> list = getAll(c);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == id) {
                list.remove(i);
                break;
            }
        }
        writeAll(c, list);
    }

    /** يحدّث نص آخر حالة إرسال فقط، دون إعادة إنشاء جدول تم حذفه. */
    public static synchronized void updateStatus(Context c, int id, String status) {
        List<Schedule> list = getAll(c);
        for (Schedule s : list) {
            if (s.id == id) {
                s.lastStatus = status;
                writeAll(c, list);
                return;
            }
        }
    }
}
