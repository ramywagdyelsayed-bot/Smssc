package com.example.smsscheduler;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

/** رسالة مجدولة (أسبوعية أو شهرية). */
public class Schedule {
    public static final int WEEKLY = 0;
    public static final int MONTHLY = 1;

    public int id;
    public String name = "";
    public String phone = "";
    public String message = "";
    public int type = WEEKLY;
    public int dayOfWeek = Calendar.SATURDAY; // قيم Calendar: 1=الأحد ... 7=السبت
    public int dayOfMonth = 1;                // 1..31
    public int hour = 9;
    public int minute = 0;
    public boolean enabled = true;
    public String lastStatus = "";

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("phone", phone);
        o.put("message", message);
        o.put("type", type);
        o.put("dayOfWeek", dayOfWeek);
        o.put("dayOfMonth", dayOfMonth);
        o.put("hour", hour);
        o.put("minute", minute);
        o.put("enabled", enabled);
        o.put("lastStatus", lastStatus);
        return o;
    }

    public static Schedule fromJson(JSONObject o) {
        Schedule s = new Schedule();
        s.id = o.optInt("id");
        s.name = o.optString("name", "");
        s.phone = o.optString("phone", "");
        s.message = o.optString("message", "");
        s.type = o.optInt("type", WEEKLY);
        s.dayOfWeek = o.optInt("dayOfWeek", Calendar.SATURDAY);
        s.dayOfMonth = o.optInt("dayOfMonth", 1);
        s.hour = o.optInt("hour", 9);
        s.minute = o.optInt("minute", 0);
        s.enabled = o.optBoolean("enabled", true);
        s.lastStatus = o.optString("lastStatus", "");
        return s;
    }

    /** الاسم مع الرقم للعرض. */
    public String target() {
        return name.isEmpty() ? phone : name + " (" + phone + ")";
    }
}
