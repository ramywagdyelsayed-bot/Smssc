package com.example.smsscheduler;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** إرسال الرسالة النصية عبر شريحة الهاتف ثم إظهار التنبيه بنتيجة الإرسال. */
public class SmsSender {

    @SuppressWarnings("deprecation")
    public static void send(Context context, Schedule s) {
        Context app = context.getApplicationContext();

        if (app.checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            report(app, s, false, "صلاحية إرسال الرسائل غير ممنوحة للتطبيق");
            return;
        }

        try {
            SmsManager sms = Build.VERSION.SDK_INT >= 31
                    ? app.getSystemService(SmsManager.class)
                    : SmsManager.getDefault();

            ArrayList<String> parts = sms.divideMessage(s.message);

            Intent result = new Intent(app, SmsResultReceiver.class);
            result.putExtra("id", s.id);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT
                    | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            int req = (int) (System.currentTimeMillis() & 0x7fffffff);
            PendingIntent pi = PendingIntent.getBroadcast(app, req, result, flags);

            // نتيجة الإرسال تُرسل مرة واحدة فقط (مع آخر جزء من الرسالة)
            ArrayList<PendingIntent> sent = new ArrayList<>();
            for (int i = 0; i < parts.size(); i++) {
                sent.add(i == parts.size() - 1 ? pi : null);
            }
            sms.sendMultipartTextMessage(s.phone, null, parts, sent, null);
        } catch (Exception e) {
            report(app, s, false, "تعذر الإرسال: " + e.getMessage());
        }
    }

    /** يحفظ آخر حالة ويُظهر التنبيه. s قد تكون null إذا حُذف الجدول أثناء الإرسال. */
    public static void report(Context context, Schedule s, boolean ok, String reason) {
        String time = new SimpleDateFormat("d/M HH:mm", Locale.US).format(new Date());
        String status = (ok ? "✔ تم الإرسال " : "✘ فشل الإرسال ") + time
                + ((ok || reason == null) ? "" : " - " + reason);
        if (s != null) {
            ScheduleStore.updateStatus(context, s.id, status);
        }

        String target = s != null ? s.target() : "";
        String body = s != null ? s.message : "";
        if (ok) {
            Notifier.show(context, "تم إرسال الرسالة ✔",
                    "إلى: " + target + "\n" + body);
        } else {
            Notifier.show(context, "فشل إرسال الرسالة ✘",
                    (target.isEmpty() ? "" : "إلى: " + target + "\n")
                            + (reason == null ? "" : reason));
        }
    }
}
