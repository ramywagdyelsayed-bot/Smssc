package com.example.smsscheduler;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** يُستدعى عند حلول موعد الرسالة: يجدول الموعد التالي ثم يرسل الرسالة. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", -1);
        Schedule s = ScheduleStore.get(context, id);
        if (s == null || !s.enabled) return;

        // جدولة الموعد القادم أولاً (مع هامش دقيقة لتجنب التكرار إذا وصل المنبّه مبكراً)
        Scheduler.schedule(context, s, System.currentTimeMillis() + 60_000L);

        SmsSender.send(context, s);
    }
}
