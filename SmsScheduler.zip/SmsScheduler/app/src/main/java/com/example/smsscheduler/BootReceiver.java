package com.example.smsscheduler;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** يعيد ضبط كل المواعيد بعد إعادة تشغيل الهاتف أو تغيير الوقت/المنطقة الزمنية أو تحديث التطبيق. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Scheduler.rescheduleAll(context);
    }
}
