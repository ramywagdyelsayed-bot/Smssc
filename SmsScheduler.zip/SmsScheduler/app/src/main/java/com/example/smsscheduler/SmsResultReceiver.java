package com.example.smsscheduler;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

/** يستقبل نتيجة الإرسال الفعلية من النظام (نجاح أو فشل) ويُظهر التنبيه. */
public class SmsResultReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", -1);
        Schedule s = ScheduleStore.get(context, id);
        int code = getResultCode();

        if (code == Activity.RESULT_OK) {
            SmsSender.report(context, s, true, null);
            return;
        }

        String reason;
        switch (code) {
            case SmsManager.RESULT_ERROR_RADIO_OFF:
                reason = "وضع الطيران مفعّل";
                break;
            case SmsManager.RESULT_ERROR_NO_SERVICE:
                reason = "لا توجد خدمة شبكة";
                break;
            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                reason = "خطأ عام (تأكد من الشريحة والرصيد)";
                break;
            default:
                reason = "رمز الخطأ: " + code;
        }
        SmsSender.report(context, s, false, reason);
    }
}
