package com.example.smsscheduler;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** تنبيه (إشعار بصوت واهتزاز) يظهر عند إرسال الرسالة. */
public class Notifier {
    private static final String CHANNEL_ID = "sms_alerts";

    public static void show(Context context, String title, String text) {
        Context c = context.getApplicationContext();
        NotificationManager nm = c.getSystemService(NotificationManager.class);

        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "تنبيهات الإرسال", NotificationManager.IMPORTANCE_HIGH);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 400, 200, 400});
        nm.createNotificationChannel(ch);

        Intent open = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();

        nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), n);
    }
}
